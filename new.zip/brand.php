<?php
	$domainName = "compressfilesonline.live";
	$domainURL = "http://compressfilesonline.live";
	$icon_loc = "./img/icon.png";
	$main_title = "Compress JPG / JPEG Images Online for Free";  // Title of the Site
	
	$contact_email = "abhayofc@yahoo.com,";
?>